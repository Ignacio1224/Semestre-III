﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ServicioArtesanos
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IService1" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IServicioArtesanal
    {
        [OperationContract]
        bool InsertarArtesano(DtoArtesano unArtesano);
         
    }    //fin interfaz

    [DataContract]
    public class DtoArtesano
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Cedula { get; set; } //identificador del artesano
        [DataMember]
        public string Nombre { get; set; }
        [DataMember]
        public string Apellido { get; set; }

    }


}
