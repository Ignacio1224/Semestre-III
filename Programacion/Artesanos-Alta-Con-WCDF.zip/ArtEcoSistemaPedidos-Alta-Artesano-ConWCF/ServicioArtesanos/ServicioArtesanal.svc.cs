﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using ArtEco.Dominio;
using ArtEco.Dominio.InterfacesRepositorio;
using ArtEco.Dominio.Repositorios.Ado;

namespace ServicioArtesanos
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service1" en el código, en svc y en el archivo de configuración.
    // NOTE: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione Service1.svc o Service1.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class ServicioArtesanal : IServicioArtesanal
    {
        public bool InsertarArtesano(DtoArtesano unArtesano)
        {
            RepositorioArtesanosADO repo = new RepositorioArtesanosADO();
            if (unArtesano != null)
            {
                Artesano a = new Artesano
                {
                    Nombre = unArtesano.Nombre,
                    Apellido = unArtesano.Apellido,
                    Cedula = unArtesano.Cedula
                };
                return repo.Add(a);
            }
            return false;
        }
    }
}
