﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArtEco.Dominio.Utilidades
{
    class UtilidadesBD
    {
        private static string cadenaConexion = 
            @"SERVER=(localdb)\mssqllocaldb;
            DATABASE=ArtEco;
            INTEGRATED SECURITY=TRUE;";
        public static SqlConnection CrearConexion()
        {
            return new SqlConnection(cadenaConexion);
        }
        public static bool CerrarConexion(SqlConnection cn)
        {
            if (cn.State == 
                System.Data.ConnectionState.Open){
                cn.Close();
                return true;
            }
            return false;
        }
        public static bool AbrirConexion(SqlConnection cn)
        {
            if (cn.State !=
                System.Data.ConnectionState.Open)
            {
                cn.Open();
                return true;
            }
            return false;
        }

    }
}
