﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using ArtEco.Dominio.Utilidades;

namespace ArtEco.Dominio
{
    public class Artesano : Persona,
        IEquatable<Artesano>, IActiveRecord
    {
        public int Id { get; set; }
        public string Cedula { get; set; } //identificador del artesano
        public override bool Validar()
        {
            return base.Validar() && this.Cedula.Length > 2 && Cedula.Length < 5;
        }


        public bool Equals(Artesano other)
        {
            return other != null && this.Cedula == other.Cedula;
        }
        public override string ToString()
        {
            return this.Cedula + " " + base.ToString();
        }

        public bool Insertar()
        {
            SqlConnection cn =
               Utilidades.UtilidadesBD.CrearConexion();
            SqlTransaction trn = null;
            try
            {
                //Preparar el comando
                string cadenaCmd =
                    @"INSERT INTO Persona 
                VALUES(@nombre,@ape);
                SELECT CAST (Scope_Identity() AS INT)";
                SqlCommand cmd =
                    new SqlCommand(cadenaCmd, cn);
                /* cmd.Parameters.Add
                     (new SqlParameter("@cedu", this.Cedula));*/
                cmd.Parameters.Add
                    (new SqlParameter("@nombre", this.Nombre));
                cmd.Parameters.AddWithValue("@ape", this.Apellido);
                UtilidadesBD.AbrirConexion(cn);
                //Se inicia la transacción
                trn = cn.BeginTransaction();
                cmd.Transaction = trn;
                int idGenerado = (int)cmd.ExecuteScalar();
                cadenaCmd =
                @"INSERT INTO Artesano  (id, cedula)
                VALUES(@id,@cedu);";
                SqlCommand cmd2 =
          new SqlCommand(cadenaCmd, cn);
                cmd2.Parameters.Add
          (new SqlParameter("@id", idGenerado));

                cmd2.Parameters.Add
                     (new SqlParameter("@cedu", this.Cedula));
                cmd2.Transaction = trn;

                cmd2.ExecuteNonQuery();
                trn.Commit();
                return true;
            }
            catch (Exception ex)
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                UtilidadesBD.CerrarConexion(cn);
            }
        }

        public bool Eliminar()
        {
            throw new NotImplementedException();
        }

        public bool Modificar()
        {
            throw new NotImplementedException();
        }
    }
}
