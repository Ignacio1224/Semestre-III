﻿using ArtEco.Dominio.Utilidades;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArtEco.Dominio.Repositorios.Ado
{
    public class RepositorioArtesanosADO :
         InterfacesRepositorio.IRepositorioArtesanos
    {
        public bool Add(Artesano art)
        {
            return art != null && art.Insertar();
        }

        public bool Delete(Artesano art)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Artesano> FindAll()
        {
            List<Artesano> lista = new List<Artesano>();
            SqlConnection cn =
    Utilidades.UtilidadesBD.CrearConexion();
            string consulta = @"SELECT * FROM Artesano";
            //Preparar el comando

            SqlCommand cmd =
                new SqlCommand(consulta, cn);

            UtilidadesBD.AbrirConexion(cn);
            SqlDataReader dr = cmd.ExecuteReader();
            //Leer el reader y cargar los objetos en la lista de retorno
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    lista.Add(new Artesano
                    {
                        Cedula = dr["Cedula"].ToString(),
                        Nombre = dr["Nombre"].ToString(),
                        Apellido = dr["Apellido"].ToString(),

                    });
                }
            }
            UtilidadesBD.CerrarConexion(cn);
            return lista;

        }

        public Artesano FindById(string cedula)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Artesano> FindByName(string nom)
        {
            throw new NotImplementedException();
        }

        public bool Update(Artesano art)
        {
            throw new NotImplementedException();
        }
    }
}
