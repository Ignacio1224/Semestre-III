USE master
GO
CREATE DATABASE ArtEco
GO

USE ArtEco
 CREATE TABLE Persona
(
	 id int PRIMARY KEY NOT NULL identity(1,1)
	,Nombre NVARCHAR(50)
	,Apellido NVARCHAR(50)
)
GO

CREATE TABLE Artesano
(
	  id int primary key foreign key references Persona(id)
	 ,Cedula nvarchar(10) 
	 
)
GO
select * from persona
select * from artesano