﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArtEco.Dominio
{
    public class Artesano:Persona, IEquatable<Artesano>
    {
        public string Cedula { get; set; } //identificador del artesano
        public override bool Validar()
        {
            return base.Validar() && this.Cedula.Length > 2 && Cedula.Length < 5;
        }
       

        public bool Equals(Artesano other)
        {
            return other !=null && this.Cedula ==other.Cedula;
        }
        public override string ToString()
        {
            return this.Cedula + " " + base.ToString();
        }
    }
}
